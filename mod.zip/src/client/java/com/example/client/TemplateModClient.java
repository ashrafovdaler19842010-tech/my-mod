package com.example.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;

public class TemplateModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of("template-mod", "velocity_indicator"),
                TemplateModClient::renderSquare
        );
    }

    private static void renderSquare(DrawContext drawContext, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;

        if (player == null) return;

        double velocityY = player.getVelocity().y;
        int color;

        if (velocityY > 0.01) {
            color = 0xFFFF0000; // ������� (����� �����)
        } else if (velocityY < -0.08) {
            color = 0xFFFF69B4; // ������� (������)
        } else {
            color = 0xFFFFFFFF; // ����� (�����)
        }

        int x = 5;
        int y = 5;
        int size = 10;
        drawContext.fill(x, y, x + size, y + size, color);
    }
}
